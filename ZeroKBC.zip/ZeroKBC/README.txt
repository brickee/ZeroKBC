ZeroKBC Benchamrk
Standard: train.tsv/valid.tsv/test.tsv
ZeroE: otrain.tsv/ovalid.tsv/otest.tsv
ZeroR: train_ZS.tsv/valid_ZS.tsv/test_ZS.tsv
ZeroB: otrain_ZS.tsv/ovalid_ZS.tsv/otest_ZS.tsv
ID mapping and textual descriptions: entity2id_text.tsv/relation2id_text.tsv